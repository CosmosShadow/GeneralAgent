## Down the Rabbit Hole

![Down the Rabbit Hole](55212d2f639d.png)

Alice starts her adventure by following the White Rabbit down a deep hole.

## The Pool of Tears

![The Pool of Tears](c5f29576e4ba.png)

After shrinking, Alice swims through her own tears and meets a Mouse.

## A Caucus-Race and a Long Tale

![A Caucus-Race and a Long Tale](0a5764360808.png)

Alice joins the Dodo's race to get dry and listens to the Mouse's long and sad tale.

## The Rabbit Sends in a Little Bill

![The Rabbit Sends in a Little Bill](1b2886636bb7.png)

The White Rabbit mistakes Alice for his servant and sends her on an errand.

## Advice from a Caterpillar

![Advice from a Caterpillar](0e80dfa3466f.png)

Alice meets a Caterpillar who gives her some advice on how to control her size.

## Pig and Pepper

![Pig and Pepper](6e29f6ababbc.png)

A chaotic visit to the Duchess's house, where Alice meets the Cheshire Cat.

## A Mad Tea-Party

![A Mad Tea-Party](59d486edefe1.png)

Alice becomes a guest at a mad tea-party with the March Hare, the Hatter, and the Dormouse.

## The Queen's Croquet Ground

![The Queen's Croquet Ground](debdbeb95a31.png)

Alice plays croquet with the Queen of Hearts and her playing card soldiers.

## The Mock Turtle's Story

![The Mock Turtle's Story](6ae443e8ff8c.png)

Alice hears the sad tale of the Mock Turtle, accompanied by the Gryphon.

## Alice's Evidence

![Alice's Evidence](b4897aebbef8.png)

Alice attends a trial and ends up growing to a giant size inside the courtroom.

